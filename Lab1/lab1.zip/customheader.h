/*Richard Zhou */
#define INIT 1


