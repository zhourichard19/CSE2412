/*Richard Zhou*/

#include <stdio.h>
#include <stdlib.h>
#include "header.h"

struct node* createNode(char val){
	/*creates a new node with the structure delcared in header.h*/
	struct node* newNode =(struct node*) malloc(sizeof(struct node));
	/*sets the new data to the character which is going to be inputted*/
	newNode->data = val;
	/*sets the new node to be pointing at null right and left sides*/
	newNode->left = newNode->right = NULL;
	return newNode;
}
