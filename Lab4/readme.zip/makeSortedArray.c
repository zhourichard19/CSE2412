/*Richard Zhou*/
#include <stdio.h>
#include <stdlib.h>
#include "header.h"

void makeSortedArray(struct node* rootPtr, char *arr){

	/*declares variables used in the function*/	
	int i = 0;
	int j = 0;	
	int minIndex = 0;

	/*if the root is null, it makesand startes making the array and fills with all of the tree nodes*/
        if(rootPtr !=NULL){
                makeSortedArray(rootPtr->left,arr);
                arr[i] = rootPtr->data;
                makeSortedArray(rootPtr->right,arr);
		i = i + 1;
        }
	
	/*enters each value into the array one by one by comparing themto each other and making the array sorted*/	
	for(i = 0; j < sizeof(arr)-1;i++){
		minIndex = i;
		for(j = i + 1;j < sizeof(arr); j++){
			if(arr[j] < arr[minIndex]){
				minIndex = j;
			}
			swap(&arr[minIndex], &arr[i]);
		}	
	}
}
