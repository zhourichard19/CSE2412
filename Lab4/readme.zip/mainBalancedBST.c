/*Richard Zhou*/

#include <stdio.h>
#include <stdlib.h>
#include "header.h"

int main(){
	 /*declare needed variables to run in the function*/	
	struct node* rootPtr = NULL;
	struct node* tree = NULL;
        int isTrue = 1;
	int i = 0;
	int x = 0;
	char arr[100] = {0};	
	int space = 0;

	/*loop around so that the user will prompted for their tree input until they are enter a prompt to quit*/
        while(isTrue == 1){
		/*declares the value of char to save to the user input*/
                char idqp;
                /*prompts the user for what they want to do and then saves it to idqp*/
                printf("Would you like to Insert[i] a value, Delete[d] a value, Print [p] the tree, or Quit[q]./n");
                idqp = getchar();
		getchar();

                /*if the user wants to insert*/
                if(idqp == 'i'){
                        /*declares the value for char and prompts the user for what they want to insert then saves it to char*/
                        char val;
                        printf("What letter would you like to insert?\n");
                        val = getchar();
                        getchar();
                        /*calls insert to insert a letter the user wanted*/
                        rootPtr = insert(rootPtr,val);
                }
                /*if the user inputs a d to delete*/
                 else if(idqp == 'd'){
                        /*declares the variable del and then asks the user which value they would like to delete*/
                        char del;
                        /*if the tree is empty, then dont delete anything*/
                        if(rootPtr == NULL){
                                printf("there is nothing currently in the tree.Please try again\n");
                        	}
		}
 		else if(idqp == 'd'){
                        /*declares the variable del and then asks the user which value they would like to delete*/
                        char del;
                        /*if the tree is empty, then dont delete anything*/
                        if(rootPtr == NULL){
                                printf("there is nothing currently in the tree.Please try again\n");
                        	}
		}	
                else if(idqp == 'p'){
                        if(rootPtr == NULL){
                                printf("there is nothing inserted in the tree so nothing will print./n");
                        }
			/*makes an array from the characters which are used*/
			makeSortedArray(rootPtr,arr);
			/*finds the middle character to balance with the middle character*/
			x = sizeof(arr) - 1;
			/*creates a balanced seard tree from the middle node out*/
			tree = createBalancedBST(tree,arr,0,x);

                        printTree(tree,space);
                }
		else{
                        printf("You did not enter an i p or q so the program will quit. Thank you./n");
                        isTrue = 0;
                }

        }
        return 0;
}

