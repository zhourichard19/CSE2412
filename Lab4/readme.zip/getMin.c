/*Richard Zhou*/

#include <stdio.h>
#include <stdlib.h>
#include "header.h"

char getMin(struct node* rootPtr){
	struct node* var = rootPtr;
	while(var->left != NULL){
		var = var->left;
	}
	return var->data;
}
