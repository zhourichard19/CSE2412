/*Richard Zhou*/
#include <stdio.h>
#include <stdlib.h>
#include "header.h"

int fileBalancedBST(char *arr){
	/*declares variables used in the code*/
	struct node* rootPtr =(struct node*) malloc(sizeof(struct node));
        int x = 0;
	int space = 0;
	int i = 0;
	int j = 0;
	int minIndex = 0;
	/*enters each value into the array one by one by comparing themto each other and making the array sorted*/
        for(i = 0; j < sizeof(arr)-1;i++){
                minIndex = i;
                for(j = i + 1;j < sizeof(arr); j++){
                        if(arr[j] < arr[minIndex]){
                                minIndex = j;
                        }
                        swap(&arr[minIndex], &arr[i]);
                }
        }
	/*lowers the size of the array to get the next value*/
	x = sizeof(arr) - 1;
	/*creates the balancees BST of the array from the middle of the array*/
	rootPtr = createBalancedBST(rootPtr, arr,0,x);
	/*prints the tree*/
	printTree(rootPtr,space);
	return 0;
}

