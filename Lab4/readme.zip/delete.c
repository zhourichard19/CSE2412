/*Richard Zhou*/

#include <stdio.h>
#include <stdlib.h>
#include "header.h"

struct node* delete(struct node* rootPtr,char data){
	/*if there is nothing in the tree currently the pointer will be returned*/
	if(rootPtr == NULL){
		return rootPtr;
	}
	/*if the data is less than the pointer node, then the function will be recursivley called on the left side*/
	else if(data < rootPtr->data){
		rootPtr->left = delete(rootPtr->left,data);
	}
	/*if the data is greater than the pointer node, then the function will be recursivley called on the right side*/
	else if(data > rootPtr->data){
		rootPtr->right = delete(rootPtr->right,data);
	}
	else{
		/*if there are no leaves*/
		if(rootPtr->left == NULL && rootPtr->right == NULL){
			/*clear the memory allocation of the node*/	
			free(rootPtr);
			rootPtr = NULL;
		}
		/*if there is one leaf on the right*/
		else if(rootPtr->left == NULL){	
			/*creates a temperary pointer to store values and swap*/	
			struct node *var = rootPtr;
			rootPtr = rootPtr->right;
			free(var);
		}
		/*if there is one leaf on the left*/
		else if(rootPtr->right ==NULL){
			/*creates a temperary pointer to store values and swap on the left*/
			struct node *var = rootPtr;
			rootPtr = rootPtr->left;
			free(var);
		}
		/*if there are 2 leaves*/
		else{
			struct node *var = NULL;
			/*finds the minimum of the leaves on the right and moves that to the left*/
			var = getMin(rootPtr->right);
			rootPtr->right = delete(rootPtr->right,var->data);
		}
	}
	return rootPtr;
}
