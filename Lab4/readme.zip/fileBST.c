/*Richard Zhou*/

#include <stdio.h>
#include <stdlib.h>
#include "header.h"

int fileBST(char *arr){
	/*declares variables that will be used*/
	char val; 
	struct node* rootPtr = NULL;
	int space = 0;
	int i = 0;
	
	/*loops through the array and inserts the values one by one*/
	for(i = 0; i < sizeof(arr); i++){
		val = arr[i];
		rootPtr = insert(rootPtr, val);
	}
	/*prints out the tree*/
	printTree(rootPtr,space);

	return 0;
}
