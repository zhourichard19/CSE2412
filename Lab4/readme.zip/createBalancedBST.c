/*Richard Zhou*/
#include <stdio.h>
#include <stdlib.h>
#include "header.h"

struct node* createBalancedBST(struct node* tree, char arr[], int first, int last){
	/*sets the variables used in the method*/
	int mid = 0;	

	/*makes sure that the tree is holding values*/
	if(first> last){
		return NULL;
	}

	/*everytime mid is called, divides the mid so that there is a new value updating with the shortening of the array*/
	mid = (first + last)/2;
	/*makes tree the node that is the next one in the middle*/
	tree = createNode(arr[mid]);
	
	/*recursively calls the tleft side first wti h mid going from the first to the middle*/
	tree->left = createBalancedBST(tree,arr, first, mid - 1);
	/*recursivley calls the right side which goes from the middle to the last node*/
	tree->right = createBalancedBST(tree,arr, mid + 1, last);

	return tree;

}
