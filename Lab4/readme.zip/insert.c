/*Richard Zhou*/

#include <stdio.h>
#include <stdlib.h>
#include "header.h"

struct node* insert(struct node* rootPtr, char data){
	/*checks to make sure that the tree is not empty and if it is, a new node will be made*/
	if(rootPtr == NULL){
		rootPtr = createNode(data);
	}
	/*checks to see if the node the pointer is at is greater than the data.*/
	/**/
	else if(data <= rootPtr->data){
		/*if the pointer is greater then the pointer sets the added char on the left side*/
		rootPtr->left = insert(rootPtr->left,data);
	}
	else{
		/*sets the pointer to the right side of the tree if it is larger*/
		rootPtr->right = insert(rootPtr->right,data);
	}
	return rootPtr;
}
