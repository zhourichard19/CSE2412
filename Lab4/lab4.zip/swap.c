/*Richard Zhou*/
#include <stdio.h>
#include <stdlib.h>
#include "header.h"

void swap(char* x, char* y){
	/*creates a temperary variable which would switch the elements inside of the array*/
	char temp = *x;
	*x = *y;
	*y = temp;
}
