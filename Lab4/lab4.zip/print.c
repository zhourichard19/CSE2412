/*Richard Zhou*/

#include <stdio.h>
#include <stdlib.h>
#include "header.h"

void printTree(struct node *rootPtr, int space){

	/*declares variables used in the method*/
	int i;

	/*checks to see if the tree is empty, if not end*/
	if (rootPtr == NULL){
		return;
	}
	
	/*sets the default spacing of the tree to 10*/
	space += 10;
	/*recursively calls printing of the tree starting on the right side*/
	printTree(rootPtr->right, space);
	printf("\n");
	
	/*prints out each space depending on where in the tree the characer is*/
	for (i = 10; i < space; i++){
		printf(" ");
	}
	/*prints out the last node in the tree that is left*/
	printf("%c\n", rootPtr->data);
	/*prints the tree out on the left side*/
	printTree(rootPtr->left, space);

}
