/*Richard Zhou*/

/*imports in a sense the used functions in the method*/
#include <stdio.h>
#include <stdlib.h>
#include "header.h"

/*encrypts 8 characters by using the bits of the 8th character and making them the most significant bit in the other7 characters*/
void encrypt(char buffer[]){
	/*declares varables to be used*/
	unsigned char new,temp, key, ch;
	int i = 0;

	/*loops thru the array to encrypt each character*/
	for(i = 0; i < DIGITS - 1; i++){
		/*takes character out of the array and sets to char*/
		ch = buffer[i];
		/*makes the last character the key in order to encrypt*/
		key = buffer[7];
		/*bitshift the last char amount of times needed for the respective bit location,then shifts to the right until it is the most significant bit with 0s till the last one*/
		temp = (key >> i) << 7;
		/*ors the char with the key to set the most significant bit to the encrypted one */
		new = ch | temp;
		/*puts the encrypted character into the outputfile*/
		putchar(new);
	}
}
